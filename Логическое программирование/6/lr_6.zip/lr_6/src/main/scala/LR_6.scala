object LR_6 extends App{

  // Структура данных для категории расходов
  case class Category(name: String, expenses: List[Double])

  // Список расходов по категориям
  val expensesByCategory = List(
    Category("Продукты", List(4000.0, 400.0, 600.0)),
    Category("Транспорт", List(500.0, 500.0)),
    Category("Развлечения", List(2000.0, 2000.0, 1000.0))
  )

  // Функция для вычисления общей суммы расходов по всем категориям
  def totalExpenses(categories: List[Category]): Double = {
    @scala.annotation.tailrec
    def sumByCategory(currentSum: Double, tailCategories: List[Category]): Double = {
      tailCategories match {
        case Nil =>
          currentSum
        case head :: tail =>
          sumByCategory(currentSum + head.expenses.sum, tail)
      }
    }

    sumByCategory(0.0, categories)
  }

  // Вычисление общей суммы расходов по всем категориям
  val total = totalExpenses(expensesByCategory)
  println("Общая сумма расходов: " + total)
}
